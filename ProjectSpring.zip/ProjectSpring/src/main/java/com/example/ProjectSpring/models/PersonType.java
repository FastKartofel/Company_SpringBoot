package com.example.ProjectSpring.models;

public enum PersonType {
    INTERNAL, EXTERNAL
}